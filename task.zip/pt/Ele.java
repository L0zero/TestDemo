package pt;

public interface Ele {

    public int getLine();

    @Override
    public String toString();
}
