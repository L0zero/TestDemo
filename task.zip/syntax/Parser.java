package syntax;

import pt.ParseTree;

public interface Parser {

    public ParseTree parse() throws Exception;
}
