package error;

public class BackwardException extends RuntimeException {
    public BackwardException(String message) {
        super(message);
    }
}
