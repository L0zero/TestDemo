package error;

public class NameExistsException extends Exception {

    public NameExistsException() {}

}
