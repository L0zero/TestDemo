package error;

public class ParsingException extends RuntimeException {
    public ParsingException(String message) {
        super(message);
    }
}
