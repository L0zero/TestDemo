package error;

public class CalculateException extends Exception {
    public CalculateException(String message) {
        super(message);
    }
}
