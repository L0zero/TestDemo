package error;

public class IRError extends CompilerError{

    public IRError(int line, String message) {
        super(line, message);
    }
}
