package debug;

public class Debug {

    public static final boolean DEBUG = true;

    public static final boolean GEN_BASIC_FUNCS = false;

    public static final boolean OPTIMIZE = true;

}
