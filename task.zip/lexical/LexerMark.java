package lexical;

import error.LoggerMark;

public class LexerMark {
    protected LoggerMark loggerMark;
    protected int pos;
}
